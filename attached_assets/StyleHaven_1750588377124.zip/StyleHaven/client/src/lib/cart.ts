import { createContext, useContext } from "react";
import type { CartContextType } from "./types";

export const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};

export const generateSessionId = () => {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
};
