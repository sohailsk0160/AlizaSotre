import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, ShoppingCart, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useCart } from "@/lib/cart";

interface HeaderProps {
  onSearch?: (query: string) => void;
}

export function Header({ onSearch }: HeaderProps) {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cartCount } = useCart();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim() && onSearch) {
      onSearch(searchQuery.trim());
    }
  };

  const navLinks = [
    { href: "/", label: "Home", active: location === "/" },
    { href: "/category/ladies-dresses", label: "Ladies", active: location.includes("ladies-dresses") },
    { href: "/category/handbags", label: "Handbags", active: location.includes("handbags") },
    { href: "/category/beauty-products", label: "Beauty", active: location.includes("beauty-products") },
    { href: "/category/kids-toys", label: "Kids", active: location.includes("kids-toys") },
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20 lg:h-24 gap-6">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link href="/">
              <h1 className="text-2xl lg:text-3xl font-bold text-aliza-primary cursor-pointer">
                Aliza Store
              </h1>
            </Link>
          </div>

          {/* Search Form - Desktop */}
          <div className="hidden md:flex flex-1 max-w-xl">
            <form onSubmit={handleSearch} className="w-full flex border-2 border-aliza-primary rounded-xl overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow duration-300">
              <Input
                type="search"
                placeholder="Search for products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-0 focus-visible:ring-0 placeholder:text-amber-600"
              />
              <Button
                type="submit"
                className="bg-aliza-primary text-white px-6 hover:bg-amber-600 transition-colors duration-300 rounded-none"
              >
                <Search className="h-5 w-5" />
              </Button>
            </form>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden lg:flex space-x-8">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`font-medium transition-colors duration-300 cursor-pointer ${
                    link.active
                      ? "text-aliza-primary font-bold border-b-3 border-aliza-primary pb-1"
                      : "text-gray-600 hover:text-aliza-primary"
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* Cart and Mobile Menu */}
          <div className="flex items-center gap-4">
            <Link href="/cart">
              <Button variant="ghost" className="relative p-2">
                <ShoppingCart className="h-6 w-6 text-gray-600 hover:text-aliza-primary transition-colors" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-aliza-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* Mobile Menu */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" className="lg:hidden p-2">
                  <Menu className="h-6 w-6 text-aliza-primary" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px]">
                <div className="flex flex-col gap-6 pt-8">
                  {/* Mobile Search */}
                  <form onSubmit={handleSearch} className="flex border-2 border-aliza-primary rounded-xl overflow-hidden">
                    <Input
                      type="search"
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="border-0 focus-visible:ring-0"
                    />
                    <Button type="submit" className="bg-aliza-primary hover:bg-amber-600 rounded-none">
                      <Search className="h-4 w-4" />
                    </Button>
                  </form>

                  {/* Mobile Navigation */}
                  <nav className="flex flex-col gap-4">
                    {navLinks.map((link) => (
                      <Link key={link.href} href={link.href}>
                        <span
                          className={`text-lg font-medium transition-colors duration-300 cursor-pointer ${
                            link.active ? "text-aliza-primary" : "text-gray-600 hover:text-aliza-primary"
                          }`}
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          {link.label}
                        </span>
                      </Link>
                    ))}
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Mobile Search - Below header */}
        <div className="md:hidden pb-4">
          <form onSubmit={handleSearch} className="flex border-2 border-aliza-primary rounded-xl overflow-hidden bg-white">
            <Input
              type="search"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="border-0 focus-visible:ring-0 placeholder:text-amber-600"
            />
            <Button type="submit" className="bg-aliza-primary hover:bg-amber-600 rounded-none">
              <Search className="h-5 w-5" />
            </Button>
          </form>
        </div>
      </div>
    </header>
  );
}
