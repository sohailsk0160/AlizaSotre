import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useCart } from "@/lib/cart";
import { Link } from "wouter";
import type { ProductWithCategory } from "@shared/schema";

export function TrendingSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const { addToCart, isLoading } = useCart();

  const { data: trendingProducts = [], isLoading: productsLoading } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products/trending"],
  });

  const itemsPerView = 4;
  const maxIndex = Math.max(0, trendingProducts.length - itemsPerView);

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlaying || trendingProducts.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
    }, 4000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, maxIndex, trendingProducts.length]);

  const handlePrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex(prev => (prev <= 0 ? maxIndex : prev - 1));
  };

  const handleNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
  };

  const handleAddToCart = async (e: React.MouseEvent, productId: number) => {
    e.preventDefault();
    e.stopPropagation();
    await addToCart(productId);
  };

  if (productsLoading) {
    return (
      <section className="py-8 bg-gradient-to-r from-aliza-primary/10 to-aliza-secondary/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-center gap-3 mb-6">
            <TrendingUp className="h-6 w-6 text-aliza-primary" />
            <h2 className="text-2xl font-bold text-aliza-primary">Trending Products</h2>
          </div>
          <div className="flex gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex-1 bg-white rounded-xl shadow-md overflow-hidden animate-pulse">
                <div className="w-full h-48 bg-gray-300"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-300 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-3"></div>
                  <div className="h-8 bg-gray-300 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (trendingProducts.length === 0) return null;

  return (
    <section className="py-8 bg-gradient-to-r from-aliza-primary/10 to-aliza-secondary/10 border-b border-aliza-primary/20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-center gap-3 mb-6">
          <TrendingUp className="h-6 w-6 text-aliza-primary animate-pulse-slow" />
          <h2 className="text-2xl font-bold text-aliza-primary">Trending Products</h2>
          <TrendingUp className="h-6 w-6 text-aliza-primary animate-pulse-slow" />
        </div>

        <div className="relative">
          {/* Navigation Buttons */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handlePrevious}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white shadow-lg rounded-full w-10 h-10 p-0"
            disabled={trendingProducts.length <= itemsPerView}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white shadow-lg rounded-full w-10 h-10 p-0"
            disabled={trendingProducts.length <= itemsPerView}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>

          {/* Products Container */}
          <div className="overflow-hidden mx-8">
            <div 
              className="flex transition-transform duration-500 ease-in-out gap-4"
              style={{ 
                transform: `translateX(-${currentIndex * (100 / itemsPerView)}%)`,
                width: `${(trendingProducts.length / itemsPerView) * 100}%`
              }}
            >
              {trendingProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex-shrink-0"
                  style={{ width: `${100 / trendingProducts.length}%` }}
                >
                  <Link href={`/product/${product.id}`}>
                    <Card className="trending-card bg-white rounded-xl shadow-md hover:shadow-xl overflow-hidden group cursor-pointer h-full animate-slide-in">
                      <div className="relative">
                        <img
                          src={product.imageUrl || ""}
                          alt={product.name}
                          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                        />
                        <div className="absolute top-2 left-2 bg-aliza-accent text-white text-xs px-2 py-1 rounded-full font-bold">
                          Trending
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-sm mb-1 line-clamp-2">{product.name}</h3>
                        <p className="text-xs text-gray-600 mb-2">{product.category.name}</p>
                        <p className="text-aliza-primary font-bold text-lg mb-3">${product.price}</p>
                        <Button
                          onClick={(e) => handleAddToCart(e, product.id)}
                          disabled={isLoading || !product.inStock}
                          size="sm"
                          className="w-full bg-aliza-primary text-white hover:bg-amber-600 transition-colors duration-300 text-xs"
                        >
                          {!product.inStock ? "Out of Stock" : "Add to Cart"}
                        </Button>
                      </CardContent>
                    </Card>
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Indicators */}
          <div className="flex justify-center mt-6 gap-2">
            {Array.from({ length: maxIndex + 1 }).map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setIsAutoPlaying(false);
                  setCurrentIndex(index);
                }}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex 
                    ? "bg-aliza-primary w-6" 
                    : "bg-aliza-primary/30 hover:bg-aliza-primary/50"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Auto-play toggle */}
        <div className="flex justify-center mt-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            className="text-aliza-primary hover:text-amber-600 text-xs"
          >
            {isAutoPlaying ? "Pause Auto-play" : "Resume Auto-play"}
          </Button>
        </div>
      </div>
    </section>
  );
}