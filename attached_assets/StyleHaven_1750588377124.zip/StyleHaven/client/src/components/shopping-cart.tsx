import { useState } from "react";
import { Minus, Plus, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useCart } from "@/lib/cart";

interface ShoppingCartProps {
  children: React.ReactNode;
}

export function ShoppingCart({ children }: ShoppingCartProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { cartItems, cartTotal, updateCartItem, removeFromCart, clearCart, isLoading } = useCart();

  const handleUpdateQuantity = async (id: number, currentQuantity: number, increment: boolean) => {
    const newQuantity = increment ? currentQuantity + 1 : currentQuantity - 1;
    if (newQuantity > 0) {
      await updateCartItem(id, newQuantity);
    }
  };

  const handleRemoveItem = async (id: number) => {
    await removeFromCart(id);
  };

  const handleClearCart = async () => {
    await clearCart();
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        {children}
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-2xl">
        <SheetHeader>
          <SheetTitle className="text-2xl font-bold text-aliza-primary">Shopping Cart</SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col h-full">
          {cartItems.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gray-600 mb-2">Your cart is empty</h3>
                <p className="text-gray-500">Add some products to get started!</p>
              </div>
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto py-6">
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <Card key={item.id} className="p-4 border border-gray-200">
                      <div className="flex items-center gap-4">
                        <img
                          src={item.product.imageUrl || ""}
                          alt={item.product.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-lg">{item.product.name}</h4>
                          <p className="text-gray-600">{item.product.category.name}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-aliza-primary text-lg">
                            ${(parseFloat(item.product.price) * item.quantity).toFixed(2)}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleUpdateQuantity(item.id, item.quantity, false)}
                              disabled={isLoading || item.quantity <= 1}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleUpdateQuantity(item.id, item.quantity, true)}
                              disabled={isLoading}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleRemoveItem(item.id)}
                              disabled={isLoading}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6 mt-6 space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-xl font-semibold">Total:</span>
                  <span className="text-2xl font-bold text-aliza-primary">${cartTotal.toFixed(2)}</span>
                </div>
                
                <div className="space-y-2">
                  <Button
                    className="w-full bg-aliza-primary text-white hover:bg-amber-600 text-lg py-3"
                    onClick={() => {
                      setIsOpen(false);
                      // TODO: Navigate to checkout
                    }}
                    disabled={isLoading}
                  >
                    Proceed to Checkout
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleClearCart}
                    disabled={isLoading}
                  >
                    Clear Cart
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
