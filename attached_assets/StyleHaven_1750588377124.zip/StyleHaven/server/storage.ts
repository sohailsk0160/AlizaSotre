import { categories, products, cartItems, adminUsers, adminSessions, type Category, type Product, type CartItem, type InsertCategory, type InsertProduct, type InsertCartItem, type ProductWithCategory, type CartItemWithProduct, type AdminUser, type InsertAdminUser, type AdminSession } from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, sql, and, gt } from "drizzle-orm";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Products
  getProducts(): Promise<Product[]>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductsWithCategory(): Promise<ProductWithCategory[]>;
  getProductsWithCategoryByCategory(categoryId: number): Promise<ProductWithCategory[]>;
  searchProducts(query: string): Promise<ProductWithCategory[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Cart
  getCartItems(sessionId: string): Promise<CartItemWithProduct[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<void>;

  // Admin
  createAdminUser(admin: InsertAdminUser): Promise<AdminUser>;
  getAdminByUsername(username: string): Promise<AdminUser | undefined>;
  verifyAdminPassword(username: string, password: string): Promise<AdminUser | null>;
  createAdminSession(adminId: number): Promise<string>;
  getAdminByToken(token: string): Promise<AdminUser | null>;
  deleteAdminSession(token: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeData();
  }

  private async initializeData() {
    try {
      // Check if categories already exist
      const existingCategories = await db.select().from(categories);
      if (existingCategories.length > 0) {
        console.log("Database already initialized");
        return;
      }

      // Create categories
      const categoriesData = [
        { name: "Ladies Dresses", slug: "ladies-dresses", description: "Elegant & stylish dresses for every occasion", imageUrl: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" },
        { name: "Handbags", slug: "handbags", description: "Premium handbags & accessories", imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" },
        { name: "Beauty Products", slug: "beauty-products", description: "Premium skincare & makeup essentials", imageUrl: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" },
        { name: "Kids Toys", slug: "kids-toys", description: "Educational & fun toys for children", imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" }
      ];

      for (const categoryData of categoriesData) {
        await this.createCategory(categoryData);
      }

      // Create products
      const productsData = [
        // Ladies Dresses - Using provided images
        { name: "Elegant Blue Anarkali Dress", description: "Beautiful blue anarkali dress with intricate embroidery perfect for special occasions", price: "89.99", imageUrl: "/attached_assets/dress1_1750582102339.png", categoryId: 1, inStock: true },
        { name: "Classic Black Dress", description: "Timeless black dress suitable for any event", price: "124.99", imageUrl: "/attached_assets/dress2_1750582102339.jpeg", categoryId: 1, inStock: true },
        { name: "Emerald Green Designer Dress", description: "Stunning emerald green dress with gold embellishments", price: "167.50", imageUrl: "/attached_assets/dress3_1750582102340.jpg", categoryId: 1, inStock: true },
        { name: "Maroon Party Dress", description: "Glamorous maroon dress perfect for parties and celebrations", price: "156.00", imageUrl: "/attached_assets/dress4_1750582102341.jpg", categoryId: 1, inStock: true },
        { name: "Colorful Casual Dress", description: "Bright and colorful dress for everyday wear", price: "78.25", imageUrl: "/attached_assets/dress5_1750582102342.jpg", categoryId: 1, inStock: true },
        { name: "Royal Blue Evening Dress", description: "Elegant royal blue dress for evening events", price: "112.00", imageUrl: "/attached_assets/dress6_1750582102342.jpeg", categoryId: 1, inStock: true },

        // Handbags
        { name: "Stylish Leather Handbag", description: "Premium leather handbag with elegant design", price: "199.99", imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 2, inStock: true },
        { name: "Luxury Leather Purse", description: "High-quality leather purse with multiple compartments", price: "245.00", imageUrl: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 2, inStock: true },
        { name: "Vintage Style Tote", description: "Classic vintage-inspired tote bag", price: "167.50", imageUrl: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 2, inStock: true },
        { name: "Modern Crossbody Bag", description: "Contemporary crossbody bag for everyday use", price: "134.99", imageUrl: "https://images.unsplash.com/photo-1594223274512-ad4803739b7c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 2, inStock: true },
        { name: "Evening Clutch", description: "Elegant clutch perfect for evening events", price: "89.00", imageUrl: "https://images.unsplash.com/photo-1566043539549-2bbfc6a3b26e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 2, inStock: true },
        { name: "Designer Shoulder Bag", description: "Luxury designer shoulder bag", price: "299.99", imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 2, inStock: true },

        // Beauty Products
        { name: "Luxury Skincare Set", description: "Complete skincare routine with premium ingredients", price: "89.99", imageUrl: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 3, inStock: true },
        { name: "Organic Makeup Palette", description: "Natural makeup palette with vibrant colors", price: "67.50", imageUrl: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 3, inStock: true },
        { name: "Premium Fragrance Collection", description: "Exquisite fragrance collection for all occasions", price: "156.00", imageUrl: "https://images.unsplash.com/photo-1541643600914-78b084683601?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 3, inStock: true },
        { name: "Anti-Aging Moisturizer", description: "Advanced anti-aging moisturizer with natural ingredients", price: "43.25", imageUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 3, inStock: true },
        { name: "Luxury Lipstick Set", description: "Premium lipstick collection in various shades", price: "29.99", imageUrl: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 3, inStock: true },
        { name: "Professional Makeup Brushes", description: "High-quality makeup brushes for professional results", price: "78.00", imageUrl: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 3, inStock: true },

        // Kids Toys
        { name: "Educational Building Blocks", description: "Colorful building blocks for creative learning", price: "34.99", imageUrl: "https://images.unsplash.com/photo-1515630278258-407f66498911?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 4, inStock: true },
        { name: "Wooden Puzzle Set", description: "Educational wooden puzzles for problem-solving skills", price: "24.50", imageUrl: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 4, inStock: true },
        { name: "Stuffed Animal Collection", description: "Soft and cuddly stuffed animals for comfort", price: "39.75", imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 4, inStock: true },
        { name: "Action Figure Set", description: "Exciting action figures for imaginative play", price: "19.99", imageUrl: "https://images.unsplash.com/photo-1572375992501-4b0892d50c69?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 4, inStock: true },
        { name: "Miniature Dollhouse", description: "Detailed dollhouse for creative storytelling", price: "127.50", imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 4, inStock: true },
        { name: "Learning Games Set", description: "Interactive learning games for cognitive development", price: "45.99", imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500", categoryId: 4, inStock: true },
      ];

      for (const productData of productsData) {
        await this.createProduct(productData);
      }

      // Create default admin user
      await this.createAdminUser({
        username: "admin",
        email: "admin@alizastore.com",
        passwordHash: await bcrypt.hash("admin123", 10),
        role: "admin"
      });

      console.log("Database initialized with sample data");
    } catch (error) {
      console.error("Error initializing data:", error);
    }
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(categoryData).returning();
    return category;
  }

  async updateCategory(id: number, categoryData: Partial<InsertCategory>): Promise<Category | undefined> {
    const [category] = await db.update(categories).set(categoryData).where(eq(categories.id, id)).returning();
    return category;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return result.rowCount > 0;
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.categoryId, categoryId));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getProductsWithCategory(): Promise<ProductWithCategory[]> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      description: products.description,
      imageUrl: products.imageUrl,
      price: products.price,
      categoryId: products.categoryId,
      inStock: products.inStock,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        slug: categories.slug,
        description: categories.description,
        imageUrl: categories.imageUrl
      }
    })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id));
    
    return result.map(row => ({
      ...row,
      category: row.category
    }));
  }

  async getProductsWithCategoryByCategory(categoryId: number): Promise<ProductWithCategory[]> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      description: products.description,
      imageUrl: products.imageUrl,
      price: products.price,
      categoryId: products.categoryId,
      inStock: products.inStock,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        slug: categories.slug,
        description: categories.description,
        imageUrl: categories.imageUrl
      }
    })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.categoryId, categoryId));
    
    return result.map(row => ({
      ...row,
      category: row.category
    }));
  }

  async searchProducts(query: string): Promise<ProductWithCategory[]> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      description: products.description,
      imageUrl: products.imageUrl,
      price: products.price,
      categoryId: products.categoryId,
      inStock: products.inStock,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        slug: categories.slug,
        description: categories.description,
        imageUrl: categories.imageUrl
      }
    })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(like(products.name, `%${query}%`));
    
    return result.map(row => ({
      ...row,
      category: row.category
    }));
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(productData).returning();
    return product;
  }

  async updateProduct(id: number, productData: Partial<InsertProduct>): Promise<Product | undefined> {
    const [product] = await db.update(products).set(productData).where(eq(products.id, id)).returning();
    return product;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItemWithProduct[]> {
    const result = await db.select({
      id: cartItems.id,
      productId: cartItems.productId,
      quantity: cartItems.quantity,
      sessionId: cartItems.sessionId,
      createdAt: cartItems.createdAt,
      product: {
        id: products.id,
        name: products.name,
        description: products.description,
        imageUrl: products.imageUrl,
        price: products.price,
        categoryId: products.categoryId,
        inStock: products.inStock,
        createdAt: products.createdAt,
        category: {
          id: categories.id,
          name: categories.name,
          slug: categories.slug,
          description: categories.description,
          imageUrl: categories.imageUrl
        }
      }
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(cartItems.sessionId, sessionId));

    return result.map(row => ({
      ...row,
      product: {
        ...row.product,
        category: row.product.category
      }
    }));
  }

  async addToCart(itemData: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const [existingItem] = await db.select().from(cartItems)
      .where(and(
        eq(cartItems.productId, itemData.productId),
        eq(cartItems.sessionId, itemData.sessionId)
      ));

    if (existingItem) {
      // Update quantity
      const [updatedItem] = await db.update(cartItems)
        .set({ quantity: existingItem.quantity + (itemData.quantity || 1) })
        .where(eq(cartItems.id, existingItem.id))
        .returning();
      return updatedItem;
    } else {
      // Create new item
      const [item] = await db.insert(cartItems).values(itemData).returning();
      return item;
    }
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const [item] = await db.update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return item;
  }

  async removeFromCart(id: number): Promise<boolean> {
    const result = await db.delete(cartItems).where(eq(cartItems.id, id));
    return (result.rowCount || 0) > 0;
  }

  async clearCart(sessionId: string): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.sessionId, sessionId));
  }

  // Admin
  async createAdminUser(adminData: InsertAdminUser): Promise<AdminUser> {
    const [admin] = await db.insert(adminUsers).values(adminData).returning();
    return admin;
  }

  async getAdminByUsername(username: string): Promise<AdminUser | undefined> {
    const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.username, username));
    return admin;
  }

  async verifyAdminPassword(username: string, password: string): Promise<AdminUser | null> {
    const admin = await this.getAdminByUsername(username);
    if (!admin) return null;
    
    const isValid = await bcrypt.compare(password, admin.passwordHash);
    return isValid ? admin : null;
  }

  async createAdminSession(adminId: number): Promise<string> {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    
    await db.insert(adminSessions).values({
      adminId,
      token,
      expiresAt
    });
    
    return token;
  }

  async getAdminByToken(token: string): Promise<AdminUser | null> {
    const result = await db.select()
    .from(adminSessions)
    .innerJoin(adminUsers, eq(adminSessions.adminId, adminUsers.id))
    .where(and(
      eq(adminSessions.token, token),
      gt(adminSessions.expiresAt, new Date())
    ));

    return result[0]?.admin_users || null;
  }

  async deleteAdminSession(token: string): Promise<boolean> {
    const result = await db.delete(adminSessions).where(eq(adminSessions.token, token));
    return (result.rowCount || 0) > 0;
  }
}

export const storage = new DatabaseStorage();
